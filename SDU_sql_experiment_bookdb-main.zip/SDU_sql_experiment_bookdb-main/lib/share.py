class SI:
    g_mainWindow = None
    g_bookInfoModel = None
    g_userInfoModel = None
    g_userId = None
